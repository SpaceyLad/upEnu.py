function printSmiley() {
    for (let i = 0; i < 1000; i++) {
        setTimeout(function timer() {
            var rNr = Math.floor(Math.random() * smiley.length);
            smile.innerHTML = smiley[rNr];
        }, i * 2000);
    }
}
printSmiley();

//Oh! Since this is a secret folder. I'll keep my password here :) admin:nimda