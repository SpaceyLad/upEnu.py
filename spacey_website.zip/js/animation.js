function printStuff() {
    for (let i = 0; i < animation.length; i++) {
        setTimeout(function timer() {
            lText.innerHTML = animation[i];
            rText.innerHTML = animation[i];
        }, i * 150);
    }
}

function welcome() {
    //msg.innerHTML ="e";
    for (let i = 0; i < welcomeMsg.length; i++) {
        setTimeout(function timer() {
            msg.innerHTML = welcomeMsg[i];
        }, i * 200);
    }
}
function welcomeOne() {
    msgOne.innerHTML ="e";
    for (let i = 0; i < oneLineMsg.length; i++) {
        setTimeout(function timer() {
            msgOne.innerHTML = oneLineMsg[i];
        }, i * 300);
    }
}
printStuff();
welcome();
welcomeOne();
// Should I keep all this is one file? Probably not..