function check() {
  if (userName.value == "Luring") {
      if (passWord.value == sText[2]) {
          printMessage.innerHTML = "Welcome!";
          printRight();
      } else {
          printMessage.innerHTML = wrongMsg;
          printWrong();
      }
  } else {
      printMessage.innerHTML = wrongMsg;
      printWrong();
  }
}
btn.onclick = check;