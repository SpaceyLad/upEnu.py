function printWrong() {
  for (let i = 0; i < animation.length; i++) {
      setTimeout(function timer() {
          lText.innerHTML = animationWrong[i];
          rText.innerHTML = animationWrong[i];
      }, i * 100);
  }
}

function printRight() {
  for (let i = 0; i < animation.length; i++) {
      setTimeout(function timer() {
          lText.innerHTML = animationRight[i];
          rText.innerHTML = animationRight[i];
      }, i * 100);
  }
}
/*
      This has been quite fun to work with.
      Hope it is usefull for someone else! :]
*/